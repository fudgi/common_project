-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 03, 2019 at 09:42 AM
-- Server version: 5.7.23
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `Rething`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `datestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `datestamp`) VALUES
(1, 'Все', '2019-01-08 16:15:19'),
(2, 'Транспорт', '2019-01-08 16:15:19'),
(3, 'Бытовая электроника', '2019-01-08 16:18:00'),
(4, 'Аудио и видео', '2019-01-08 16:18:00'),
(5, 'Личные вещи', '2019-01-08 16:18:00'),
(6, 'Хобби и отдых', '2019-01-08 16:18:00'),
(7, 'Фототехника', '2019-01-08 16:18:00'),
(8, 'Для дома и дачи', '2019-01-08 16:18:00'),
(9, 'Товары для компьютера', '2019-01-08 16:18:00'),
(10, 'Разное', '2019-01-08 16:18:00');

-- --------------------------------------------------------

--
-- Table structure for table `photo_list`
--

CREATE TABLE `photo_list` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `respond_id` bigint(20) UNSIGNED NOT NULL,
  `imageURL` text COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `photo_list`
--

INSERT INTO `photo_list` (`id`, `respond_id`, `imageURL`, `timestamp`) VALUES
(18, 81, '/img/respondImages/9_81_IMG_1983.JPG', '2019-02-23 13:29:24'),
(19, 81, '/react-app-07/src/img/respondImages/9_81_IMG_1984.JPG', '2019-02-23 13:29:24'),
(20, 81, '/react-app-07/src/img/respondImages/9_81_IMG_1985.JPG', '2019-02-23 13:29:24'),
(21, 81, '/react-app-07/src/img/respondImages/9_81_IMG_1986.JPG', '2019-02-23 13:29:24'),
(22, 81, '/react-app-07/src/img/respondImages/9_81_IMG_1987.JPG', '2019-02-23 13:29:24'),
(23, 81, '/react-app-07/src/img/respondImages/9_81_fullsizeoutput_10.jpeg', '2019-02-23 13:29:24'),
(36, 87, '/react-app-07/src/img/respondImages/9_87_IMG_1983.JPG', '2019-02-24 10:12:54'),
(37, 87, '/react-app-07/src/img/respondImages/9_87_IMG_1984.JPG', '2019-02-24 10:12:54'),
(38, 87, '/react-app-07/src/img/respondImages/9_87_IMG_1985.JPG', '2019-02-24 10:12:54'),
(39, 90, '/react-app-07/src/img/respondImages/9_90_IMG_1983.JPG', '2019-03-01 06:33:15'),
(40, 90, '/react-app-07/src/img/respondImages/9_90_IMG_1984.JPG', '2019-03-01 06:33:15'),
(41, 90, '/react-app-07/src/img/respondImages/9_90_IMG_1985.JPG', '2019-03-01 06:33:15'),
(42, 91, '/react-app-07/src/img/respondImages/_91_IMG_1983.JPG', '2019-03-01 17:30:36'),
(43, 91, '/react-app-07/src/img/respondImages/_91_IMG_1984.JPG', '2019-03-01 17:30:36'),
(44, 92, '/react-app-07/src/img/respondImages/_92_IMG_1983.JPG', '2019-03-01 17:32:55'),
(45, 92, '/react-app-07/src/img/respondImages/_92_IMG_1984.JPG', '2019-03-01 17:32:55'),
(46, 92, '/react-app-07/src/img/respondImages/_92_IMG_1985.JPG', '2019-03-01 17:32:55'),
(47, 93, '/react-app-07/src/img/respondImages/4_93_IMG_1981.JPG', '2019-03-01 17:35:58'),
(48, 93, '/react-app-07/src/img/respondImages/4_93_IMG_1982.JPG', '2019-03-01 17:35:58');

-- --------------------------------------------------------

--
-- Table structure for table `request_data`
--

CREATE TABLE `request_data` (
  `request_id` bigint(20) UNSIGNED NOT NULL,
  `creator_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `request_title` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `request_whenDate` datetime NOT NULL,
  `request_tillDate` datetime NOT NULL,
  `request_price` decimal(20,2) UNSIGNED DEFAULT NULL,
  `request_description` text COLLATE utf8_unicode_ci NOT NULL,
  `request_location` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `request_active` tinyint(1) UNSIGNED DEFAULT NULL,
  `request_confirmed_respond` bigint(20) UNSIGNED DEFAULT NULL,
  `request_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `category_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `request_data`
--

INSERT INTO `request_data` (`request_id`, `creator_user_id`, `request_title`, `request_whenDate`, `request_tillDate`, `request_price`, `request_description`, `request_location`, `request_active`, `request_confirmed_respond`, `request_timestamp`, `category_id`) VALUES
(2, 2, 'Карета', '2018-11-20 23:25:00', '2018-11-24 02:00:00', '5000.00', 'Покататься', 'Зимний дворец', 1, NULL, '2018-11-17 07:49:18', 2),
(4, 2, 'Муза', '2018-11-21 00:00:00', '2018-11-29 00:00:00', '2000.00', 'Позовите модератора', 'Домой', 1, NULL, '2018-11-17 07:57:58', 8),
(5, 4, 'Ручка перьевая', '2019-01-09 00:00:00', '2019-01-11 00:00:00', '200.00', 'Сущий пустячок', 'Покровский бульвар, 4', 1, NULL, '2019-01-08 18:03:11', 5),
(6, 7, 'Дрель, скорее', '2019-01-15 00:00:00', '2019-01-17 00:00:00', '500.00', 'Мощная дрель для соседей', 'Петровка, 5', 1, NULL, '2019-01-08 18:04:11', 3),
(7, 9, 'Храбрость', '2019-01-21 00:00:00', '2019-01-28 00:00:00', '5000.00', 'Хочу быть храбрым', 'Карла Маркса, 21', 1, NULL, '2019-01-08 18:11:09', 5),
(8, 9, 'Мозги', '2019-01-21 00:00:00', '2019-01-28 00:00:00', '456.00', 'Хочу быть умным', 'Изумрудный город', 1, NULL, '2019-01-08 18:12:03', 5),
(9, 8, 'Лопата совковая', '2019-01-23 00:00:00', '2019-01-24 00:00:00', '200.00', 'Выкопать картошку', 'сады Березка', 1, NULL, '2019-01-22 01:52:07', 8),
(10, 8, 'Газель', '2019-01-28 00:00:00', '2019-01-24 00:00:00', '2000.00', 'Переезжаю', 'В черте города', 1, NULL, '2019-01-22 01:52:07', 2),
(24, 9, 'Утюг', '2019-01-30 00:00:00', '2019-01-31 00:00:00', '1000.00', 'Чтобы грел ночами', 'ул. Пушкина', 1, 24, '2019-01-27 07:45:03', 3),
(25, 9, 'AD', '2019-01-31 00:00:00', '2019-02-07 00:00:00', '1.00', 'ASD', 'and', 1, NULL, '2019-01-31 02:40:39', 3),
(26, 9, 'das', '2019-02-01 00:00:00', '2019-01-02 00:00:00', '3.00', 'pdf', 'sfdfsd', 1, 72, '2019-01-31 02:41:34', 3),
(27, 9, 'hjjhj', '2019-02-20 00:00:00', '2019-02-27 00:00:00', '45.00', 'sfds', 'sadfsd', 1, 70, '2019-02-15 18:50:39', 9),
(30, 1, 'Лекарство от здоровья', '2019-02-21 00:00:00', '2019-02-22 00:00:00', '3000.00', 'Очень болен', 'ул. Пушкина, д. Колотушкина', 1, NULL, '2019-02-19 18:51:14', 5),
(31, 3, 'Лошадь', '2019-03-12 00:00:00', '2019-02-22 00:00:00', '6000.00', 'Гнедую', 'Конюшня', 1, NULL, '2019-02-19 18:51:14', 2),
(32, 9, '353', '2019-03-01 00:00:00', '2019-02-08 00:00:00', '3.00', 'sdfffds', 'sdfdfss', 1, 88, '2019-02-24 09:58:50', 4),
(33, 9, 'мышь', '2019-02-25 00:00:00', '2019-03-04 00:00:00', '54.00', 'ываывмсчсмы', 'чмчмчсм', 1, NULL, '2019-02-25 09:59:48', 6),
(34, 8, 'Магнитофон', '2019-03-02 00:00:00', '2019-03-09 00:00:00', '423.00', 'вфыфывыфв', 'вфыфвфыв', 1, NULL, '2019-03-01 16:44:46', 4);

-- --------------------------------------------------------

--
-- Table structure for table `request_respond_data`
--

CREATE TABLE `request_respond_data` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `request_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'Отвечающий',
  `price` decimal(20,2) NOT NULL,
  `respond_text` text COLLATE utf8_unicode_ci,
  `state` tinyint(1) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `request_respond_data`
--

INSERT INTO `request_respond_data` (`id`, `request_id`, `user_id`, `price`, `respond_text`, `state`, `timestamp`) VALUES
(19, 6, 9, '4.00', 'def', 0, '2019-01-20 18:15:20'),
(22, 8, 4, '200.00', 'У меня есть', 0, '2019-01-22 02:12:56'),
(24, 24, 8, '500.00', 'Норм', 1, '2019-01-27 07:46:14'),
(26, 8, 7, '200.00', 'adsdasdsadsdfsfsdfsfsf', 0, '2019-01-27 11:01:12'),
(27, 24, 7, '5000.00', 'expensive', 0, '2019-01-27 15:16:02'),
(28, 24, 4, '545345.00', 'wrong', 0, '2019-01-27 15:16:02'),
(70, 27, 4, '500.00', 'Godish', 1, '2019-02-18 20:26:09'),
(71, 24, 2, '5555.00', 'sdfsdfsdvxc', 0, '2019-02-19 05:03:00'),
(72, 26, 8, '500.00', 'asdacxvfgfdgdgdfgddfgdgdfg', 1, '2019-02-19 08:10:52'),
(81, 2, 9, '50.00', 'dadasdasdasd', NULL, '2019-02-23 13:29:24'),
(82, 4, 9, '345.00', 'fsdfsdf', NULL, '2019-02-24 09:14:39'),
(87, 9, 9, '24432.00', 'fsdfsdf', NULL, '2019-02-24 10:12:54'),
(88, 32, 3, '345.00', 'fsdfdfafdsfdfadsfaffaffafsfafasffafsafsfafsafafasf', 1, '2019-02-24 10:14:50'),
(89, 32, 1, '345.00', 'fsbfsdfsdfssfsdf', 0, '2019-02-24 10:14:50'),
(90, 5, 9, '34.00', 'sad', NULL, '2019-03-01 06:33:15'),
(91, 6, 8, '234.00', 'pdf', NULL, '2019-03-01 17:30:36'),
(92, 2, 8, '34243.00', 'dsfsfsdf', NULL, '2019-03-01 17:32:55'),
(93, 4, 8, '23424.00', 'fsfdsdf', NULL, '2019-03-01 17:35:58');

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE `user_data` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Имя_Фамилия',
  `password` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `telephone` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` text COLLATE utf8_unicode_ci COMMENT 'Ссылка на фото',
  `birth_date` date DEFAULT NULL,
  `state` tinyint(1) UNSIGNED DEFAULT NULL COMMENT 'null_неАктивирован, 1_активирован, 0_блок',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`user_id`, `username`, `password`, `email`, `telephone`, `photo`, `birth_date`, `state`, `timestamp`) VALUES
(1, 'Александр Пушкин', '123', 'niggers_adventure@mail.ru', '+(955)732-43-24', '/react-app-07/src/img/user_avatar/pushkin.jpg', NULL, NULL, '2018-11-17 07:41:20'),
(2, 'Петр Первый', '123', 'piter@mail.ru', '+(955)724-32-45', '/react-app-07/src/img/user_avatar/petr.jpg', NULL, NULL, '2018-11-17 07:46:51'),
(3, 'Каретчик ВсеяРуси', '123', 'invalid1@mail.ru', '+(955)798-76-43', '/react-app-07/src/img/user_avatar/kucher.jpg', NULL, NULL, '2018-11-17 08:00:12'),
(4, 'Марина Цветаева', '123', 'ya_poet@mail.ru', '+(955)712-12-12', '/react-app-07/src/img/user_avatar/Tsvetaeva.jpg', NULL, NULL, '2018-11-17 08:01:17'),
(7, 'Алина Краснова', '123', 'alina@mail.ru', '+(955)243-34-54', '/react-app-07/src/img/user_avatar/avatar-girl.svg', NULL, NULL, '2019-01-08 16:39:43'),
(8, 'Андрей Кораблев', '123', 'korabl@mail.ru', '+(955)342-43-23', '/react-app-07/src/img/user_avatar/avatar-man-2.svg', NULL, NULL, '2019-01-08 16:40:44'),
(9, 'Миша Смирнов', '123', 'viha@mail.ru', '+(955)243-43-76', '/react-app-07/src/img/user_avatar/avatar-man-1.svg', NULL, NULL, '2019-01-08 18:07:07'),
(10, NULL, 'dsfsdf', 'ads@fsdfsdf', NULL, NULL, NULL, NULL, '2019-03-01 09:00:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD UNIQUE KEY `category_id` (`category_id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `photo_list`
--
ALTER TABLE `photo_list`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `respond_id` (`respond_id`);

--
-- Indexes for table `request_data`
--
ALTER TABLE `request_data`
  ADD PRIMARY KEY (`request_id`),
  ADD UNIQUE KEY `request_id` (`request_id`),
  ADD KEY `user_id` (`creator_user_id`),
  ADD KEY `request_confirmed_responder` (`request_confirmed_respond`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `request_respond_data`
--
ALTER TABLE `request_respond_data`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `request_id` (`request_id`);

--
-- Indexes for table `user_data`
--
ALTER TABLE `user_data`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `photo_list`
--
ALTER TABLE `photo_list`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `request_data`
--
ALTER TABLE `request_data`
  MODIFY `request_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `request_respond_data`
--
ALTER TABLE `request_respond_data`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT for table `user_data`
--
ALTER TABLE `user_data`
  MODIFY `user_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `photo_list`
--
ALTER TABLE `photo_list`
  ADD CONSTRAINT `respond_data` FOREIGN KEY (`respond_id`) REFERENCES `request_respond_data` (`id`);

--
-- Constraints for table `request_data`
--
ALTER TABLE `request_data`
  ADD CONSTRAINT `category_data` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`),
  ADD CONSTRAINT `request_data_ibfk_1` FOREIGN KEY (`request_confirmed_respond`) REFERENCES `request_respond_data` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `request_data_ibfk_2` FOREIGN KEY (`creator_user_id`) REFERENCES `user_data` (`user_id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `request_respond_data`
--
ALTER TABLE `request_respond_data`
  ADD CONSTRAINT `request_respond_data_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `request_data` (`request_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `request_respond_data_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user_data` (`user_id`) ON DELETE NO ACTION ON UPDATE CASCADE;
